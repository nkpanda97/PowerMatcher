function Aggregate_BidCurve(id,aggregate_Demand,house_number,Feeder_Number)
%This function shall plot the aggregate demand in staircase graph
%Inputs:
%      id----> The division of per unit price
%      aggregate_Demand---->The aggregate power variable (in id x n vector)
%      where n is the number of houses
%      house_number -------> The house number for which you are plotting (as '1')
%       Feeder Number----> Input the Feeder Number

n=size(aggregate_Demand,1); %Number of houses
for i=1:n
stairs(id,aggregate_Demand(i,:),'LineWidth',2);hold on
end
%plot(id(ind_lambda_star),agg_bid(ind_lambda_star),'r*','MarkerSize',10);
%plot(aggregate_Demand(index_lambda_star),aggregate_Demand(index_lambda_star),'r*','MarkerSize',10);
hold off
Text='House: ';
Text=repmat(Text,n,1);
numbering=house_number(str2double(Feeder_Number),:)';
legend_text=[Text char(numbering)];
hleg = legend(legend_text);
hleg.NumColumns = 3;
hleg.EdgeColor = 'None';
hleg.Color = 'None';
grid ON;
ax = gca;
ax.GridColor = [0 .5 .5];
ax.GridLineStyle = ':';
ax.GridAlpha = 0.5;
ax.Layer = 'top';
% 


title(['Feeder- ',Feeder_Number])
xlabel('\lambda','fontsize',13)
ylabel('Power (kW)','fontsize',13)
end