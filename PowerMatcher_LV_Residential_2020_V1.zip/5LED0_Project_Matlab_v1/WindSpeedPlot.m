clear all;
close all
clc;
Cin=3;
Cnom=8;
Coff=11;
xx=1:0.1:96;
y1=Cin.*ones(1,length(xx));
y2=Cnom.*ones(1,length(xx));
y3=Coff.*ones(1,length(xx));

load('WindSpeed.mat')
plot(WindSpeed,'-b','LineWidth',1);
hold on
plot(WindSpeed,'or','LineWidth',1);
hold on
plot(xx,y1,'--k','LineWidth',1);hold on
plot(xx,y2,'--k','LineWidth',1);hold on
plot(xx,y3,'--k','LineWidth',1);hold off
axis([0 96 1.5 11.1])
text(50,Coff-.2,'Cut-Off Speed','Color','blue','FontSize',12)
text(50,Cin-.2,'Cut-In Speed','Color','blue','FontSize',12)
text(10,Cnom-.2,'Nominal Speed','Color','blue','FontSize',12)
values_xtick={'00:00','01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00'...
    ,'10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00'...
    ,'22:00','23:00'};
xticks([1:4:96]);
xticklabels(values_xtick);
xtickangle(90)
ylabel('Speed (m/s)');
xlabel('Time steps');
title('Wind Speed on March 25th 2019 in Eindhoven');
grid on
hold on