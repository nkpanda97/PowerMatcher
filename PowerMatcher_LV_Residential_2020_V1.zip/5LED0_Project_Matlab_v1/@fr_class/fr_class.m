classdef fr_class
    %FR_CLASS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Tmin = -30; % Coldest setpoint temperature freezer [deg C]
        Tmax = -20; % Hottest setpoint temperature freezer [deg C]
        Pnom = 100;
        
        Twarmup = 0.2; % Temperature change freezer
        Tcooloff = -0.4; % Temperature change when freezer is turned on 
        
        T_FR
    end
    
    methods
        function fr = fr_class(T_FR)
            fr.T_FR = T_FR;
        end
    end
    
end

