function fr = response(fr, lamda, d)

if(d(lamda)==0)
    dT = fr.Twarmup;
else
    dT = fr.Tcooloff;
end

fr.T_FR = fr.T_FR + dT;

end