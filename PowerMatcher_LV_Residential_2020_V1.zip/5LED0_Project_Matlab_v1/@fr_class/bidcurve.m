function d = bidcurve(fr, id)

L=(fr.T_FR-fr.Tmin)/(fr.Tmax-fr.Tmin)*max(id);

d=zeros(1,length(id));

for i=1:length(id)       %create demand bid curve
    if(id(i)<=L)
        d(i)=fr.Pnom;
    else
        d(i)=0;
    end
end

end