classdef hp_class
    %UNTITLED Heat pump class
    %   Detailed explanation goes here
    
    properties
        Tmin = 20; % Min room temp [degree C]
        Tmax = 21; % Max room temp [degree C]
        
        Pnomel = 4e3; % Pnomel is the nominal power of the electric resistance heating [W]
        Pnompump = 1e3 ; %Pnompump is the nominal power of the heat pump capacity [W]
        
        COP_heatpump = 3.5; % Heat pmup COP
        COP_el = 1; % Electric heating COP
        
        Cbuilding = 65.5e6; % Thermal capacity of building [J/K]
        UA = 214; % Thermal loss due to transmission and ventilation, per degree of temperature difference [W/K]
        Qint = 300; % Internal generated heat, by people and device [W]
        
        T_HP % HP temperature
    end
    
    methods
        function hp = hp_class(T_HP)
            hp.T_HP = T_HP;
        end
    end
end

