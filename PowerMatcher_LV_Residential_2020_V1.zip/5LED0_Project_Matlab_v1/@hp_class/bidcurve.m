function d = bidcurve(hp, id)

%price is an input vector, containing the prices for which a bid curve needs to be determined

L=length(id);                %define constant for easy use in functions
A=round((hp.Tmax-hp.T_HP)/(hp.Tmax-hp.Tmin)*L);       %define constant for easy use in functions

d=zeros(1,length(id));       %create an empty vector, such that simulink knows a vector is expected

for i=1:L                      %create bid curve
    if(i<A+1)
        d(i)=(A-i+1)/A*hp.Pnomel+hp.Pnompump;
    else
        d(i)=0;
    end
end

end