function hp = response(hp, lamda, d, Te)

% Power consumed from price lamda
P_heatpump=d(lamda);

% Heat generated from consumed power
if(P_heatpump>0)
    Q_supply = hp.Pnompump*hp.COP_heatpump+(P_heatpump-hp.Pnompump)*hp.COP_el;
else
    Q_supply = 0;
end

% Temperature changed from generated heat

deltaT = Te - hp.T_HP;    % Temperature difference between inside and outside
Qout = hp.UA*deltaT;      % Heat loss due to transmission and ventilation
Qin = Q_supply + hp.Qint;    % Heat supply and internal energy supply
hp.T_HP = hp.T_HP + (Qin + Qout)*15*60/hp.Cbuilding;     % Temperature change

end