function [lstar, lstar_ind] = eqprice(input) 
% Calculates the equilibrium price for aggregate bid curve
id = 0:0.1:1;
lstar = length(id);
f = input(input>0);
for l = 1:(length(input)-1)
       if input(l)*input(l+1) <= 0
           if(abs(input(l)) > abs(input(l+1)))
               lstar = l;
           else
               lstar = l+1;
           end
       elseif isempty(f)
           lstar = 1;
       end
end

lstar = id(lstar);
lstar_ind = find(id == lstar);
end