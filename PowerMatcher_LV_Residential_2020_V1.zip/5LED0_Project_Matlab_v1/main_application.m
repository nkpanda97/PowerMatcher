close all
clear
clc;
% create bid, agregate, price send back, response
%% *Initialization of data & variables*

% Load input data for simulation
id =0:0.1:1;   % Resoluation of bid curves
load Load.mat; % Base Load measured from smart meter
load Temp.mat; % Based on temp measurement
load Irrad;  % Solar Irradance Data
load WindSpeed;
num_houses=24; %Total number of houses
id_l=length(id); %Number of steps
%% 
% *Initialising the equilibrium prices for each houses*

lambda_star = 10;

%% 
% *List all the equillibrium prices in a 24xid array*

list_lambda = zeros(96,1);
%% 
% *Intialise the settings of devices for each house*
% 
% For House-1: Nanda (CHP,Freeze, PV-Solar, Battery)

T_FR_init_H1= -25; % Initial temprature freezer [deg C]
T_CHP_init_H1 = 20.5; % Initial internal temperature for CHP [deg C]
SOC_bat_init_H1 = 55; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%
%% 
% For House-2 Nanda (CHP,Freezer, Washing Machine,EV-Charging)

T_FR_init_H2 = -20; % Initial temprature freezer [deg C]
T_CHP_init_H2 = 21.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H2 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H2 = 0; % Initial consumed energy from washing machine
SOC_ev_init_H2=58; %Initial SOC of EV 
time_leave_H2 = 8; % time when ev disconnects [h]
time_return_H2 = 20; % time when ev connects [h]
%% 
% For House-3 Nanda (CHP, Washing Machine , Freezer)

T_FR_init_H3 = -30; % Initial temprature freezer [deg C]
T_CHP_init_H3 = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H3 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H3 = 1; % Initial consumed energy from washing machine
%% 
% For House-4 Nanda (Heat Pump, Freezer, Washing machine, PV_solar,Ev Charging)

T_HP_init_H4 = 35.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H4 = -15; % Initial temprature freezer [deg C]
status_WM_init_H4 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H4 = 1; % Initial consumed energy from washing machine
SOC_ev_init_H4=72; %Initial SOC of EV 
time_leave_H4 = 9; % time when ev disconnects [h]
time_return_H4 = 18; % time when ev connects [h]
%% 
% For House-5: FILIP (uses chp, fr, wm and PV)

T_FR_init_H5 = -25; % Initial temprature freezer [deg C]
T_CHP_init_H5 = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H5 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H5 = 0; % Initial consumed energy from washing machine
%% 
% House 6 FILIP (uses hp, fr and wm)

T_HP_init_H6 = 22; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H6 = -24.3; % Initial temprature freezer [deg C]
status_WM_init_H6 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H6 = 1; % Initial consumed energy from washing machine

%% 
% %House 7 FILIP (uses hp, fr, wm, battery, PV and EV)

T_HP_init_H7 = 19.4; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H7 = -22.3; % Initial temprature freezer [deg C]
status_WM_init_H7 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H7 = 0; % Initial consumed energy from washing machine
SOC_bat_init_H7 = 35; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%
SOC_ev_init_H7 = 35; % Initial EV SOC
time_leave_H7 = 7; % time when ev disconnects [h]
time_return_H7 = 18; % time when ev connects [h]
%% 
% House 8 FILIP (uses chp, fr and wm)

T_FR_init_H8 = -26.4; % Initial temprature freezer [deg C]
T_CHP_init_H8 = 24; % Initial internal temperature for CHP [deg C]
status_WM_init_H8 = 2; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H8 = 0; % Initial consumed energy from washing machine

%% 
% House:9 NITYA = HP, FR, WM

T_HP_init_H9 = 25.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H9 = -20; % Initial temprature freezer [deg C]
% T_CHP_init = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H9 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H9 = 1; % Initial consumed energy from washing machine

%% 
% House-10 NITYA = CHP, FR, WM, PV, EV

T_FR_init_H10 = -27; % Initial temprature freezer [deg C]
T_CHP_init_H10 = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H10 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H10 = 1; % Initial consumed energy from washing machine
time_leave_H10 = 6; % time when ev disconnects [h]
time_return_H10 = 17; % time when ev connects [h]
SOC_ev_init_H10 = 30; % Initial EV SOC

%% 
% House-11 NITYA = CHP, FR, WM, PV, BAT

T_FR_init_H11 = -25; % Initial temprature freezer [deg C]
T_CHP_init_H11 = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H11 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H11 = 0; % Initial consumed energy from washing machine
SOC_bat_init_H11 = 35; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%
%% 
% House 12 NITYA = HP, WM, PV, BAT, EV, WIND

T_HP_init_H12 = 20.5; % Initial internal temperature for HeatPump [deg C]
status_WM_init_H12 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H12 = 0; % Initial consumed energy from washing machine
SOC_bat_init_H12 = 35; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%
SOC_ev_init_H12 = 20; % Initial EV SOC
time_leave_H12 = 8; % time when ev disconnects [h]
time_return_H12 = 18; % time when ev connects [h]

%% 
% House-13 (chp, hp, wm, PV)

T_CHP_init_H13 = 20.5; % Initial internal temperature for CHP [deg C]
T_HP_init_H13 = 20.5; % Initial internal temperature for HeatPump [deg C]
status_WM_init_H13 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H13 = 0; % Initial consumed energy from washing machine

%% 
% House 14 (hp, fr, wm, battery)

T_HP_init_H14 = 22; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H14 = -24.3; % Initial temprature freezer [deg C]
status_WM_init_H14 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H14 = 1; % Initial consumed energy from washing machine
SOC_bat_init_H14 = 35; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%

%% 
% House 15 (chp, fr, PV, EV)

T_CHP_init_H15 = 20.5; % Initial internal temperature for CHP [deg C]
T_FR_init_H15 = -22.3; % Initial temprature freezer [deg C]
SOC_ev_init_H15 = 35; % Initial EV SOC
time_leave_H15 = 7; % time when ev disconnects [h]
time_return_H15 = 18; % time when ev connects [h]

%% 
% House 16 (hp, fr, wm, battery)

T_HP_init_H16 = 22; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H16 = -26.4; % Initial temprature freezer [deg C]
status_WM_init_H16 = 2; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H16 = 0; % Initial consumed energy from washing machine
SOC_bat_init_H16 = 35; % Initial battery State-Of-Charge, SOC = Battery percentage 0-100%

%% 
% House 17 Geert (fr, chp, wm, wt)

T_FR_init_H17 = -22; % Initial temprature freezer [deg C]
T_CHP_init_H17 = 18.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H17 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H17 = 0; % Initial consumed energy from washing machine
SOC_ev_init_H17 = 30; % Initial EV SOC
time_leave_H17 = 9; % time when ev disconnects [h]
time_return_H17 = 19; % time when ev connects [h]

%% 
% House-18 Geert (pv, hp, fr, wm)

T_HP_init_H18 = 38.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H18 = -27; % Initial temprature freezer [deg C]
T_CHP_init_H18 = 22.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H18 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H18 = 1; % Initial consumed energy from washing machine

%% 
% Hose-19 Geert (pv, hp, fr, chp, wm)

T_HP_init_H19 = 24.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H19= -26; % Initial temprature freezer [deg C]
T_CHP_init_H19 = 19; % Initial internal temperature for CHP [deg C]
status_WM_init_H19 = 1; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H19 = 1; % Initial consumed energy from washing machine
%% 
% House 20 Geert (Freezer, Washing Machine)


T_HP_init_H20 = 31.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H20 = -16; % Initial temprature freezer [deg C]
T_CHP_init_H20 = 23; % Initial internal temperature for CHP [deg C]
status_WM_init_H20 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H20 = 1; % Initial consumed energy from washing machine

%% 
% House 21-JOK (bl, chp, fr, wm, pv)

%T_HP_init_H21 = 20.5; % Initial internal temperature for HeatPump [deg C]
T_FR_init_H21 = -25; % Initial temprature freezer [deg C]
T_CHP_init_H21 = 20.5; % Initial internal temperature for CHP [deg C]
status_WM_init_H21 = 0; % Initial status for washing machine (0 - waiting; 1 - working; 2 - finished)
E_WM_init_H21 = 0; % Initial consumed energy from washing machine

%% 
% House 22 JOK (bl, chp, fr)

T_FR_init_H22 = -22;
T_CHP_init_H22 = 20;

%% 
% House 23 JOK (bl, hp, fr, wm, pv, ev-charging)

T_HP_init_H23 = 20.8;
T_FR_init_H23 = -20;
status_WM_init_H23 = 0;
E_WM_init_H23 = 0;
SOC_ev_init_H23 = 55; % Initial EV SOC at 55%
time_leave_H23 = 8; % time when ev disconnects in the morning [8:00 h]
time_return_H23 = 18; % time when ev connects in the evening [18:00 h]

%% 
% %House 24 JOK (bl, hp, fr, wm, pv, battery, ev-charging)

T_HP_init_H24 = 20.2;
T_FR_init_H24 = -28;
status_WM_init_H24 = 0;
E_WM_init_H24 = 0;
SOC_bat_init_H24 = 50; % Initial house-battery State-Of-Charge is 50%, SOC = Battery percentage 0-100%
SOC_ev_init_H24 = 25; % Initial EV SOC at 25%
time_leave_H24 = 7; % time when ev disconnects in the morning [7:00 h]
time_return_H24 = 17; % time when ev connects in the evening [17:00 h]
%% *Create appliances separately for each house*

%H1%%%%%%%%%%%%%%%%%%%%
bl_H1 = bl_class(1*Load);
pv_H1 = pv_class(Irrad);
fr_H1 = fr_class(T_FR_init_H1);
chp_H1 = chp_class(T_CHP_init_H1);
wt_H1 = wt_class(WindSpeed);
bat_H1=bat_class(SOC_bat_init_H1);
%H2%%%%%%%%%%%%%%%%%%%%
bl_H2 = bl_class(0.96.*Load);
ev_H2=ev_class(SOC_ev_init_H2,time_leave_H2,time_return_H2);
fr_H2 = fr_class(T_FR_init_H2);
chp_H2 = chp_class(T_CHP_init_H2);
wm_H2 = wm_class(status_WM_init_H2,E_WM_init_H2);
%H3%%%%%%%%%%%%%%%%%%%%
bl_H3 = bl_class(0.89.*Load);
fr_H3 = fr_class(T_FR_init_H3);
chp_H3 = chp_class(T_CHP_init_H3);
wm_H3 = wm_class(status_WM_init_H3,E_WM_init_H3);
wt_H3=wt_class(WindSpeed);
%H4%%%%%%%%%%%%%%%%%%%%
bl_H4 = bl_class(1.2*Load);
pv_H4 = pv_class(1.5*Irrad);
hp_H4 = hp_class(T_HP_init_H4);
fr_H4 = fr_class(T_FR_init_H4);
wm_H4 = wm_class(status_WM_init_H4,E_WM_init_H4);
ev_H4=ev_class(SOC_ev_init_H4,time_leave_H4,time_return_H4);

%H5%%%%%%%%%%%%%%%%%%%%
bl_H5 = bl_class(0.78.*Load);
pv_H5 = pv_class(Irrad);
fr_H5 = fr_class(T_FR_init_H5);
chp_H5 = chp_class(T_CHP_init_H5);
wm_H5 = wm_class(status_WM_init_H5,E_WM_init_H5);
%H6%%%%%%%%%%%%%%%%%%%%
bl_H6 = bl_class(0.8.*Load);
hp_H6 = hp_class(T_HP_init_H6);
fr_H6 = fr_class(T_FR_init_H6);
wm_H6 = wm_class(status_WM_init_H6,E_WM_init_H6);
%H7%%%%%%%%%%%%%%%%%%%%
bl_H7 = bl_class(0.92.*Load);
pv_H7 = pv_class(Irrad);
hp_H7 = hp_class(T_HP_init_H7);
fr_H7 = fr_class(T_FR_init_H7);
wm_H7= wm_class(status_WM_init_H7,E_WM_init_H7);
bat_H7 = bat_class(SOC_bat_init_H7);
ev_H7 = ev_class(SOC_ev_init_H7,time_leave_H7,time_return_H7);
%H8%%%%%%%%%%%%%%%%%%%%
bl_H8 = bl_class(0.749.*Load);
pv_H8 = pv_class(Irrad);
fr_H8 = fr_class(T_FR_init_H8);
chp_H8 = chp_class(T_CHP_init_H8);
wm_H8 = wm_class(status_WM_init_H8,E_WM_init_H8);
wt_H8 = wt_class(WindSpeed);

%H9%%%%%%%%%%%%%%%%%%%%
bl_H9 = bl_class(0.925.*Load);
%pv = pv_class(Irrad);
hp_H9 = hp_class(T_HP_init_H9);
fr_H9 = fr_class(T_FR_init_H9);
% chp = chp_class(T_CHP_init);
wm_H9 = wm_class(status_WM_init_H9,E_WM_init_H9);


%H10%%%%%%%%%%%%%%%%%%%%
bl_H10 = bl_class(0.758.*Load);
pv_H10 = pv_class(Irrad);
% hp = hp_class(T_HP_init);
fr_H10 = fr_class(T_FR_init_H10);
chp_H10 = chp_class(T_CHP_init_H10);
wm_H10 = wm_class(status_WM_init_H10,E_WM_init_H10);

%H11%%%%%%%%%%%%%%%%%%%%
bl_H11 = bl_class(Load);
pv_H11 = pv_class(Irrad);
% hp = hp_class(T_HP_init);
fr_H11 = fr_class(T_FR_init_H11);
chp_H11 = chp_class(T_CHP_init_H11);
wm_H11 = wm_class(status_WM_init_H11,E_WM_init_H11);

%H12%%%%%%%%%%%%%%%%%%%
bl_H12 = bl_class(0.668.*Load);
pv_H12 = pv_class(Irrad);
hp_H12 = hp_class(T_HP_init_H12);
% fr = fr_class(T_FR_init);
% chp = chp_class(T_CHP_init);
wm_H12 = wm_class(status_WM_init_H12,E_WM_init_H12);
wt_H12 = wt_class(WindSpeed);

%House 13 (chp, hp, wm, PV)
bl_H13 = bl_class(0.7.*Load);
hp_H13 = hp_class(T_HP_init_H13);
wm_H13 = wm_class(status_WM_init_H13,E_WM_init_H13);
pv_H13 = pv_class(Irrad);
chp_H13 = chp_class(T_CHP_init_H13);
%House 14 (hp, fr, wm, battery)
bl_H14 = bl_class(0.8.*Load);
hp_H14 = hp_class(T_HP_init_H14);
wm_H14 = wm_class(status_WM_init_H14,E_WM_init_H14);
bat_H14 = bat_class(SOC_bat_init_H14);
fr_H14=fr_class(T_FR_init_H14);
%House 15 (chp, fr, PV, EV)
bl_H15 = bl_class(0.9.*Load);
chp_H15 = chp_class(T_CHP_init_H15);
fr_H15 = fr_class(T_FR_init_H15);
pv_H15 = pv_class(Irrad);
ev_H15 = ev_class(SOC_ev_init_H15,time_leave_H15,time_return_H15);

%House 16 (hp, fr, wm, battery)
bl_H16 = bl_class(Load);
hp_H16 = hp_class(T_HP_init_H16);
fr_H16 = fr_class(T_FR_init_H16);
wm_H16 = wm_class(status_WM_init_H16,E_WM_init_H16);
bat_H16 = bat_class(SOC_bat_init_H16);

%H17 (fr, chp, wm, wt)
bl_H17 = bl_class(0.64*Load);
fr_H17 = fr_class(T_FR_init_H17);
chp_H17 = chp_class(T_CHP_init_H17);
wm_H17  = wm_class(status_WM_init_H17,E_WM_init_H17);
wt_H17  = wt_class(WindSpeed);
ev_H17 = ev_class(SOC_ev_init_H17,time_leave_H17,time_return_H17);

%H18 (pv, hp, fr, wm)
bl_H18 = bl_class(0.54.*Load);
pv_H18 = pv_class(Irrad);
hp_H18 = hp_class(T_HP_init_H18);
fr_H18 = fr_class(T_FR_init_H18);
wm_H18 = wm_class(status_WM_init_H18,E_WM_init_H18);

%H19 (pv, hp, fr, chp, wm)
bl_H19 = bl_class(0.71.*Load);
pv_H19 = pv_class(Irrad);
hp_H19 = hp_class(T_HP_init_H19);
fr_H19 = fr_class(T_FR_init_H19);
chp_H19 = chp_class(T_CHP_init_H19);
wm_H19  = wm_class(status_WM_init_H19,E_WM_init_H19);

%H20 (fr, wm)
bl_H20 = bl_class(0.83.*Load);
fr_H20 = fr_class(T_FR_init_H4);
wm_H20= wm_class(status_WM_init_H4,E_WM_init_H4);

%House 21%%%%%%%%%%%%%%%%%%%%% (bl, chp, fr, wm, pv)
bl_H21 = bl_class(0.74*Load);
pv_H21 = pv_class(Irrad);
%hp_H21 = hp_class(T_HP_init_H21);
fr_H21 = fr_class(T_FR_init_H21);
chp_H21 = chp_class(T_CHP_init_H21);
wm_H21 = wm_class(status_WM_init_H21,E_WM_init_H21);

%House 22%%%%%%%%%%%%%%%%%%%% (bl, chp, fr)
bl_H22 = bl_class(0.69*Load);
%pv_H22 = pv_class(Irrad);
%hp_H22 = hp_class(T_HP_init_H22);
fr_H22 = fr_class(T_FR_init_H22);
chp_H22 = chp_class(T_CHP_init_H22);
%wm_H22 = wm_class(status_WM_init_H22,E_WM_init_H22);

%House 23%%%%%%%%%%%%%%%%%%% (bl, hp, fr, wm, pv, ev-charging)
bl_H23 = bl_class(0.99*Load);
pv_H23 = pv_class(Irrad);
hp_H23 = hp_class(T_HP_init_H23);
fr_H23 = fr_class(T_FR_init_H23);
%chp_H23 = chp_class(T_CHP_init_H23);
wm_H23 = wm_class(status_WM_init_H23,E_WM_init_H23);
ev_H23 = ev_class(SOC_ev_init_H23,time_leave_H23,time_return_H23);

%House 24%%%%%%%%%%%%%%%%%%%% (bl, hp, fr, wm, pv, battery, ev-charging)
bl_H24 = bl_class(0.812*Load);
pv_H24 = pv_class(Irrad);
hp_H24 = hp_class(T_HP_init_H24);
fr_H24 = fr_class(T_FR_init_H24);
%chp_H24 = chp_class(T_CHP_init_H24);
wm_H24 = wm_class(status_WM_init_H24,E_WM_init_H24);
bat_H24 = bat_class(SOC_bat_init_H24);
ev_H24 = ev_class(SOC_ev_init_H24,time_leave_H24,time_return_H24);

%% All Base Loads
All_Base_loads=[bl_H1.load';bl_H2.load';bl_H3.load';bl_H4.load';bl_H5.load';...
    bl_H6.load';bl_H7.load';bl_H8.load';bl_H9.load';bl_H10.load';...
    bl_H11.load';bl_H12.load';bl_H13.load';bl_H14.load';bl_H15.load';...
    bl_H16.load';bl_H17.load';bl_H18.load';bl_H19.load';bl_H20.load';...
    bl_H21.load';bl_H22.load';bl_H23.load';bl_H24.load']/1000;


%%%%%  % Initialise the array to store individual house demands
AllHouseDemands=zeros(96,24);
%% *Simulate for 96 times, evry 15 min in a 24 hours of a day*

for time = 1:24*4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Base load
    d_BL_H1 = bl_H1.bidcurve(id,time);
    d_BL_H2 = bl_H2.bidcurve(id,time);
    d_BL_H3 = bl_H3.bidcurve(id,time);
    d_BL_H4 = bl_H4.bidcurve(id,time);
    
    d_BL_H5 = bl_H5.bidcurve(id,time);
    d_BL_H6 = bl_H6.bidcurve(id,time);
    d_BL_H7 = bl_H7.bidcurve(id,time);
    d_BL_H8 = bl_H8.bidcurve(id,time);
    
    d_BL_H9 = bl_H9.bidcurve(id,time);
    d_BL_H10 = bl_H10.bidcurve(id,time);
    d_BL_H11 = bl_H11.bidcurve(id,time);
    d_BL_H12 = bl_H12.bidcurve(id,time);
    
    d_BL_H13 = bl_H13.bidcurve(id,time);
    d_BL_H14 = bl_H14.bidcurve(id,time);
    d_BL_H15 = bl_H15.bidcurve(id,time);
    d_BL_H16 = bl_H16.bidcurve(id,time);
    
    d_BL_H17 = bl_H17.bidcurve(id,time);
    d_BL_H18 = bl_H18.bidcurve(id,time);
    d_BL_H19 = bl_H19.bidcurve(id,time);
    d_BL_H20 = bl_H20.bidcurve(id,time);
    
    d_BL_H21 = bl_H21.bidcurve(id,time);
    d_BL_H22 = bl_H22.bidcurve(id,time);
    d_BL_H23 = bl_H23.bidcurve(id,time);
    d_BL_H24 = bl_H24.bidcurve(id,time);
    
    % Generate the bid curve for PV
    d_PV_H1 = pv_H1.bidcurve(id,time); 
    d_PV_H4 = pv_H4.bidcurve(id,time); 
    
    d_PV_H5 = pv_H5.bidcurve(id,time); 
    d_PV_H7 = pv_H7.bidcurve(id,time); 
    
    d_PV_H10 = pv_H10.bidcurve(id,time);
    d_PV_H11 = pv_H11.bidcurve(id,time);
    d_PV_H12 = pv_H12.bidcurve(id,time);
    
    d_PV_H13 = pv_H13.bidcurve(id,time);
    d_PV_H15 = pv_H15.bidcurve(id,time);
    
    d_PV_H18 = pv_H18.bidcurve(id,time); 
    d_PV_H19 = pv_H19.bidcurve(id,time); 
    
    d_PV_H21 = pv_H21.bidcurve(id,time);  
    d_PV_H23 = pv_H23.bidcurve(id,time);  
    d_PV_H24 = pv_H24.bidcurve(id,time); 
    
    % Generate the bid curve for flexible load
  
    d_HP_H4 = hp_H4.bidcurve(id);
    
    d_HP_H6 = hp_H6.bidcurve(id);
    d_HP_H7 = hp_H7.bidcurve(id);
    
    d_HP_H9 = hp_H9.bidcurve(id);
    d_HP_H12 = hp_H12.bidcurve(id);
    
    d_HP_H13 = hp_H13.bidcurve(id); 
    d_HP_H14 = hp_H14.bidcurve(id); 
    d_HP_H16 = hp_H16.bidcurve(id);
    
    d_HP_H18 = hp_H18.bidcurve(id); 
    d_HP_H19 = hp_H19.bidcurve(id);
    
    d_HP_H23 = hp_H23.bidcurve(id); 
    d_HP_H24 = hp_H24.bidcurve(id);
    
    % Generate the bid curve for Freezers
    d_FR_H1 = fr_H1.bidcurve(id);
    d_FR_H2 = fr_H2.bidcurve(id);
    d_FR_H3 = fr_H3.bidcurve(id);
    d_FR_H4 = fr_H4.bidcurve(id);
    
    d_FR_H5 = fr_H5.bidcurve(id);
    d_FR_H6 = fr_H6.bidcurve(id);
    d_FR_H7 = fr_H7.bidcurve(id);
    d_FR_H8 = fr_H8.bidcurve(id);
    
    d_FR_H9 = fr_H9.bidcurve(id);
    d_FR_H10 = fr_H10.bidcurve(id);
    d_FR_H11 = fr_H11.bidcurve(id);

    d_FR_H14 = fr_H14.bidcurve(id);
    d_FR_H15 = fr_H15.bidcurve(id);
    d_FR_H16 = fr_H16.bidcurve(id);
    
    d_FR_H17 = fr_H17.bidcurve(id);
    d_FR_H18 = fr_H18.bidcurve(id);
    d_FR_H19 = fr_H19.bidcurve(id);
    d_FR_H20 = fr_H20.bidcurve(id);
    
    d_FR_H21 = fr_H21.bidcurve(id);
    d_FR_H22 = fr_H22.bidcurve(id);
    d_FR_H23 = fr_H23.bidcurve(id);
    d_FR_H24 = fr_H24.bidcurve(id);
    
    % Generate the bid curve for CHP
    d_CHP_H1 = chp_H1.bidcurve(id);
    d_CHP_H2 = chp_H2.bidcurve(id);
    d_CHP_H3 = chp_H3.bidcurve(id);
    
    d_CHP_H5 = chp_H5.bidcurve(id);
    d_CHP_H8 = chp_H8.bidcurve(id);
    
    d_CHP_H10 = chp_H10.bidcurve(id);
    d_CHP_H11 = chp_H11.bidcurve(id);
    
    d_CHP_H13 = chp_H13.bidcurve(id);
    d_CHP_H15 = chp_H15.bidcurve(id);
    
    d_CHP_H17 = chp_H17.bidcurve(id);
    d_CHP_H19 = chp_H19.bidcurve(id);
    
    d_CHP_H21 = chp_H21.bidcurve(id);
    d_CHP_H22 = chp_H22.bidcurve(id);
    
    % Generate the bid curve for Washing Machine
    d_WM_H2 = wm_H2.bidcurve(id,lambda_star);
    d_WM_H3 = wm_H3.bidcurve(id,lambda_star);
    d_WM_H4 = wm_H4.bidcurve(id,lambda_star);
    
    d_WM_H5 = wm_H5.bidcurve(id,lambda_star);
    d_WM_H6 = wm_H6.bidcurve(id,lambda_star);
    d_WM_H7 = wm_H7.bidcurve(id,lambda_star);
    d_WM_H8 = wm_H8.bidcurve(id,lambda_star);
    
    d_WM_H9 = wm_H9.bidcurve(id,lambda_star);
    d_WM_H10 = wm_H10.bidcurve(id,lambda_star);
    d_WM_H11 = wm_H11.bidcurve(id,lambda_star);
    d_WM_H12 = wm_H12.bidcurve(id,lambda_star);
    
    d_WM_H13 = wm_H13.bidcurve(id,lambda_star);
    d_WM_H14 = wm_H14.bidcurve(id,lambda_star);
    d_WM_H16 = wm_H16.bidcurve(id,lambda_star);
    
    d_WM_H17 = wm_H17.bidcurve(id,lambda_star);
    d_WM_H18 = wm_H18.bidcurve(id,lambda_star);
    d_WM_H19 = wm_H19.bidcurve(id,lambda_star);
    d_WM_H20 = wm_H20.bidcurve(id,lambda_star);
    
    d_WM_H21 = wm_H21.bidcurve(id,lambda_star);
    d_WM_H23 = wm_H23.bidcurve(id,lambda_star);
    d_WM_H24 = wm_H24.bidcurve(id,lambda_star);
    
    %Generate bid curve for wind
    d_wind_H1 = wt_H1.bidcurve(id,time);
    d_wind_H8 = wt_H8.bidcurve(id,time);
    d_wind_H3 = wt_H3.bidcurve(id,time);
    d_wind_H17 = wt_H17.bidcurve(id,time);
    d_wind_H12=  wt_H12.bidcurve(id,time);
    
    %Generate bid curve for battery
    d_BAT_H1 = bat_H1.bidcurve(id);
    
    d_BAT_H7 = bat_H7.bidcurve(id);
    
    d_BAT_H14 = bat_H14.bidcurve(id); 
    d_BAT_H16 = bat_H16.bidcurve(id); 
    
    d_BAT_H24 = bat_H24.bidcurve(id);
    
    %Generate bid curve for ev
    d_EV_H2 = ev_H2.bidcurve(id, time); 
    d_EV_H4 = ev_H4.bidcurve(id, time); 
    d_EV_H7 = ev_H7.bidcurve(id, time); 
    d_EV_H15 = ev_H15.bidcurve(id, time); 
    d_EV_H23 = ev_H23.bidcurve(id, time);
    d_EV_H24 = ev_H24.bidcurve(id, time);
    d_EV_H17 = ev_H17.bidcurve(id, time);
    
    
    % determine the aggregatred bid
    agg_bid_H1 = (d_BL_H1 + d_PV_H1  + d_FR_H1 + d_CHP_H1 +...
    d_wind_H1+d_BAT_H1);
    agg_bid_H2 = (d_BL_H2 + d_EV_H2 + d_FR_H2 + d_CHP_H2 + d_WM_H2);
    agg_bid_H3 = (d_BL_H3 +  d_FR_H3 + d_CHP_H3 +....
    d_WM_H3+d_wind_H3);
    agg_bid_H4 = (d_BL_H4 + d_PV_H4 + d_HP_H4 + d_FR_H4 +d_EV_H4+ d_WM_H4);
    
    agg_bid_H5 = (d_BL_H5 + d_PV_H5 + d_FR_H5 + d_WM_H5 + d_CHP_H5);
    agg_bid_H6 = (d_BL_H6 + d_HP_H6 + d_FR_H6 + d_WM_H6 );
    agg_bid_H7 = (d_BL_H7 + 2*d_PV_H7 + d_HP_H7 + d_FR_H7 + d_WM_H7 + d_BAT_H7 + d_EV_H7);
    agg_bid_H8 = (d_BL_H8 + d_FR_H8 + d_CHP_H8 + d_WM_H8);
   
    agg_bid_H9 = (d_BL_H9 + d_HP_H9 + d_FR_H9 + d_WM_H9);
    agg_bid_H10 = (d_BL_H10 + d_PV_H10 + d_FR_H10 + d_CHP_H10 + d_WM_H10); % plus ev charging
    agg_bid_H11 = (d_BL_H11 + d_PV_H11 + d_FR_H11 + d_CHP_H11 + d_WM_H11); % plus battery
    agg_bid_H12 = (d_BL_H12 + d_PV_H12 + d_HP_H12 + d_WM_H12); % plus ev charging
 
    agg_bid_H13 = (d_BL_H13 + d_HP_H13 + d_WM_H13 + d_PV_H13); %House 13 (chp, hp, wm, PV)
    agg_bid_H14 = (d_BL_H14 + d_HP_H14 + d_FR_H14 + d_WM_H14 + d_BAT_H14);	%House 14 (hp, fr, wm, battery)
    agg_bid_H15 = (d_BL_H15 + d_CHP_H15 + d_FR_H15 + d_PV_H15 + d_EV_H15);	%House 15 (chp, fr, PV, EV)
    agg_bid_H16 = (d_BL_H16 + d_HP_H16 + d_FR_H16  + d_WM_H16 + d_BAT_H16);	%House 16 (hp, fr, wm, battery)
    
    agg_bid_H17 = (d_BL_H17 + d_FR_H17 + d_CHP_H1 + d_WM_H17 + d_wind_H17 + d_EV_H17);
    agg_bid_H18 = (d_BL_H18 + d_PV_H18 + d_HP_H18 + d_FR_H18 + d_WM_H18);
    agg_bid_H19 = (d_BL_H19 + d_PV_H19 + d_HP_H19 + d_FR_H19 + d_CHP_H19 + d_WM_H19);
    agg_bid_H20 = (d_BL_H20 + d_FR_H20 + d_WM_H20);
    
    agg_bid_H21 = (d_BL_H21 + d_PV_H21 + d_FR_H21 + d_CHP_H21 + d_WM_H21);                          %House 21%% (bl, chp, fr, wm, pv)
    agg_bid_H22 = (d_BL_H22 + d_FR_H22 + d_CHP_H22);                                                %House 22%% (bl, chp, fr)
    agg_bid_H23 = (d_BL_H23 + d_PV_H23 + d_HP_H23 + d_FR_H23 + d_WM_H23 + d_EV_H23);                %House 23%% (bl, hp, fr, wm, pv, ev-charging)
    agg_bid_H24 = (d_BL_H24 + d_PV_H24 + d_HP_H24 + d_FR_H24 + d_WM_H24 + d_BAT_H24 + d_EV_H24);    %House 24%% (bl, hp, fr, wm, pv, battery, ev-charging)
    
 

    % Plot all bid curves in a window
    TotalAggregateDemand_1=[agg_bid_H1;agg_bid_H2;agg_bid_H3;agg_bid_H4]/1000; %Stacking all demands
    TotalAggregateDemand_2=[agg_bid_H5;agg_bid_H6;agg_bid_H7;agg_bid_H8]/1000; %Stacking all demands
    TotalAggregateDemand_3=[agg_bid_H9;agg_bid_H10;agg_bid_H11;agg_bid_H12]/1000; %Stacking all demands
    TotalAggregateDemand_4=[agg_bid_H13;agg_bid_H14;agg_bid_H15;agg_bid_H16]/1000; %Stacking all demands
    TotalAggregateDemand_5=[agg_bid_H17;agg_bid_H18;agg_bid_H19;agg_bid_H20]/1000; %Stacking all demands
    TotalAggregateDemand_6=[agg_bid_H21;agg_bid_H22;agg_bid_H23;agg_bid_H24]/1000; %Stacking all demands for houses 21,22,23,24 (feeder6)
    
    HouseNumbering={'01','02','03','04';...
                   '05','06','07','08';...
                   '11','10','11','12';...
                   '13','14','15','16';...
                   '17','18','19','20';...
                   '21','22','23','24'};
               
               
  
      
    
    fig1=figure(1);
    subplot(3,2,1)
    Aggregate_BidCurve(id,TotalAggregateDemand_1,HouseNumbering,'1')
    subplot(3,2,2)
    Aggregate_BidCurve(id,TotalAggregateDemand_2,HouseNumbering,'2')
    subplot(3,2,3)
    Aggregate_BidCurve(id,TotalAggregateDemand_3,HouseNumbering,'3')
    subplot(3,2,4)
    Aggregate_BidCurve(id,TotalAggregateDemand_4,HouseNumbering,'4')
    subplot(3,2,5)
    Aggregate_BidCurve(id,TotalAggregateDemand_5,HouseNumbering,'5')
    subplot(3,2,6)
    Aggregate_BidCurve(id,TotalAggregateDemand_6,HouseNumbering,'6')
    %For all group titles
    hour = fix(time/4);
    minute = (time/4 - hour)*60;
    title_name = strcat('Bidcurves Window for Individual House @ ', num2str(hour),':', num2str(minute));
    sgtitle(title_name)
    movegui(fig1,'west')
   
    %Total Feeder Demand
    Distrubutor_1=sum(TotalAggregateDemand_1);
    Distrubutor_2=sum(TotalAggregateDemand_2);
    Distrubutor_3=sum(TotalAggregateDemand_3);
    Distrubutor_4=sum(TotalAggregateDemand_4);
    Distrubutor_5=sum(TotalAggregateDemand_5);
    Distrubutor_6=sum(TotalAggregateDemand_6);
    Distrubutor_Aggregate=[Distrubutor_1;Distrubutor_2;Distrubutor_3;Distrubutor_4;Distrubutor_5;Distrubutor_6];
    Distrubutor_total=sum(Distrubutor_Aggregate);
    Distrubutor_Numbering=['1','2','3','4','5','6'];
    
    % determine the \lambda_star value and its index
    [lambda_star, index_lambda_star]=eqprice(Distrubutor_total);
    
      %%%%%%% Saving the Demands of Households in a #-D array %%%%%%%%%
      %array--->[ time x no.of houses(24)]--- Column decides house number
      AllHouseDemands(time,1)=agg_bid_H1(1,index_lambda_star);
      AllHouseDemands(time,2)=agg_bid_H2(1,index_lambda_star);
      AllHouseDemands(time,3)=agg_bid_H3(1,index_lambda_star);
      AllHouseDemands(time,4)=agg_bid_H4(1,index_lambda_star);
      AllHouseDemands(time,5)=agg_bid_H5(1,index_lambda_star);
      AllHouseDemands(time,6)=agg_bid_H6(1,index_lambda_star);
      AllHouseDemands(time,7)=agg_bid_H7(1,index_lambda_star);
      AllHouseDemands(time,8)=agg_bid_H8(1,index_lambda_star);
      AllHouseDemands(time,9)=agg_bid_H9(1,index_lambda_star);
      AllHouseDemands(time,10)=agg_bid_H10(1,index_lambda_star);
      AllHouseDemands(time,11)=agg_bid_H11(1,index_lambda_star);
      AllHouseDemands(time,12)=agg_bid_H12(1,index_lambda_star);
      AllHouseDemands(time,13)=agg_bid_H13(1,index_lambda_star);
      AllHouseDemands(time,14)=agg_bid_H14(1,index_lambda_star);
      AllHouseDemands(time,15)=agg_bid_H15(1,index_lambda_star);
      AllHouseDemands(time,16)=agg_bid_H16(1,index_lambda_star);
      AllHouseDemands(time,17)=agg_bid_H17(1,index_lambda_star);
      AllHouseDemands(time,18)=agg_bid_H18(1,index_lambda_star);
      AllHouseDemands(time,19)=agg_bid_H19(1,index_lambda_star);
      AllHouseDemands(time,20)=agg_bid_H20(1,index_lambda_star);
      AllHouseDemands(time,21)=agg_bid_H21(1,index_lambda_star);
      AllHouseDemands(time,22)=agg_bid_H22(1,index_lambda_star);
      AllHouseDemands(time,23)=agg_bid_H23(1,index_lambda_star);
      AllHouseDemands(time,24)=agg_bid_H24(1,index_lambda_star);
    
    %Plot the feeder total
    fig2=figure(2);
    Aggregate_BidCurve_Feeder(id,[Distrubutor_Aggregate;Distrubutor_total], Distrubutor_Numbering,time,index_lambda_star)
    movegui(fig2,'east')
    
    pause(1);
    
    
    %Determine the response of the appliances for the equilibrium price
        
    fr_H1 = fr_H1.response(index_lambda_star,d_FR_H1);
    chp_H1 = chp_H1.response(index_lambda_star,d_CHP_H1,Temp(time));

    
  
    fr_H2 = fr_H2.response(index_lambda_star,d_FR_H2);
    chp_H2 = chp_H2.response(index_lambda_star,d_CHP_H2,Temp(time));
    wm_H2 = wm_H2.response(index_lambda_star,d_WM_H2);
    ev_H2 = ev_H2.response(index_lambda_star,d_EV_H2,time);
    
   
    fr_H3 = fr_H3.response(index_lambda_star,d_FR_H3);
    chp_H3 = chp_H3.response(index_lambda_star,d_CHP_H3,Temp(time));
    wm_H3 = wm_H3.response(index_lambda_star,d_WM_H3);
    
    hp_H4 = hp_H4.response(index_lambda_star,d_HP_H4,Temp(time));
    fr_H4 = fr_H4.response(index_lambda_star,d_FR_H4);
    wm_H4= wm_H4.response(index_lambda_star,d_WM_H4);
    ev_H4 = ev_H4.response(index_lambda_star,d_EV_H4,time);
    
    
    fr_H5 = fr_H5.response(index_lambda_star,d_FR_H5);
    chp_H5 = chp_H5.response(index_lambda_star,d_CHP_H5,Temp(time));
    wm_H5 = wm_H5.response(index_lambda_star,d_WM_H5);
    
    hp_H6 = hp_H6.response(index_lambda_star,d_HP_H6,Temp(time));
    fr_H6 = fr_H6.response(index_lambda_star,d_FR_H6);
    wm_H6 = wm_H6.response(index_lambda_star,d_WM_H6);
    
    hp_H7 = hp_H7.response(index_lambda_star,d_HP_H7,Temp(time));
    fr_H7 = fr_H7.response(index_lambda_star,d_FR_H7);
    wm_H7 = wm_H7.response(index_lambda_star,d_WM_H7);
    bat_H7 = bat_H7.response(index_lambda_star,d_BAT_H7);
    ev_H7 = ev_H7.response(index_lambda_star,d_EV_H7,time);
    
    fr_H8 = fr_H8.response(index_lambda_star,d_FR_H8);
    chp_H8 = chp_H8.response(index_lambda_star,d_CHP_H8,Temp(time));
    wm_H8 = wm_H8.response(index_lambda_star,d_WM_H8);    
    
    hp_H9 = hp_H9.response(index_lambda_star,d_HP_H9,Temp(time));
    fr_H9 = fr_H9.response(index_lambda_star,d_FR_H9);
    %chp = chp.response(ind_lambda_star,d_CHP,Temp(time));
    wm_H9 = wm_H9.response(index_lambda_star,d_WM_H9);
        
    fr_H10 = fr_H10.response(index_lambda_star,d_FR_H10);
    chp_H10 = chp_H10.response(index_lambda_star,d_CHP_H10,Temp(time));
    wm_H10 = wm_H10.response(index_lambda_star,d_WM_H10);
    
    fr_H11 = fr_H11.response(index_lambda_star,d_FR_H11);
    chp_H11 = chp_H11.response(index_lambda_star,d_CHP_H11,Temp(time));
    wm_H11 = wm_H11.response(index_lambda_star,d_WM_H11);
    
    hp_H12 = hp_H12.response(index_lambda_star,d_HP_H12,Temp(time));
    %fr = fr.response(ind_lambda_star,d_FR);
    %chp = chp.response(ind_lambda_star,d_CHP,Temp(time));
    wm_H12 = wm_H12.response(index_lambda_star,d_WM_H12);
    
    %House 13 (chp, hp, wm, PV)
    chp_H13 = chp_H13.response(index_lambda_star,d_CHP_H13,Temp(time));
    hp_H13 = hp_H13.response(index_lambda_star,d_HP_H13,Temp(time));
    wm_H13 = wm_H13.response(index_lambda_star,d_WM_H13);
    
    %House 14 (hp, fr, wm, battery)
    hp_H14 = hp_H14.response(index_lambda_star,d_HP_H14,Temp(time));
    fr_H14 = fr_H14.response(index_lambda_star,d_FR_H14);
    wm_H14 = wm_H14.response(index_lambda_star,d_WM_H14);
    bat_H14 = bat_H14.response(index_lambda_star,d_BAT_H14);
    
    %House 15 (chp, fr, PV, EV)
    chp_H15 = chp_H15.response(index_lambda_star,d_CHP_H15,Temp(time));
    fr_H15 = fr_H15.response(index_lambda_star,d_FR_H15);
    ev_H15 = ev_H15.response(index_lambda_star,d_EV_H15,time);
    
    %House 16 (hp, fr, wm, battery)
    hp_H16 = hp_H16.response(index_lambda_star,d_HP_H16,Temp(time));
    fr_H16 = fr_H16.response(index_lambda_star,d_FR_H16);
    wm_H16 = wm_H16.response(index_lambda_star,d_WM_H16);
    bat_H16 = bat_H16.response(index_lambda_star,d_BAT_H16);
    
    %House 17 (fr, chp, wm, ev)
    fr_H17 = fr_H17.response(index_lambda_star,d_FR_H17);
    chp_H17 = chp_H17.response(index_lambda_star,d_CHP_H17,Temp(time));
    wm_H17 = wm_H17.response(index_lambda_star,d_WM_H17);
    ev_H17 = ev_H17.response(index_lambda_star,d_EV_H17,time);
    
    %House 18 (hp, fr, wm)
    hp_H18 = hp_H18.response(index_lambda_star,d_HP_H18,Temp(time));
    fr_H18 = fr_H18.response(index_lambda_star,d_FR_H18);
    wm_H18= wm_H18.response(index_lambda_star,d_WM_H18);
    
    %House 19 (hp, fr, chp, wm)
    hp_H19 = hp_H19.response(index_lambda_star,d_HP_H19,Temp(time));
    fr_H19 = fr_H19.response(index_lambda_star,d_FR_H19);
    chp_H19 = chp_H19.response(index_lambda_star,d_CHP_H19,Temp(time));
    wm_H19= wm_H19.response(index_lambda_star,d_WM_H19);
    
    %House 20 (fr, wm)
    fr_H20 = fr_H20.response(index_lambda_star,d_FR_H20);
    wm_H20= wm_H20.response(index_lambda_star,d_WM_H20);
   
    %House 21%% (bl, chp, fr, wm, pv)
    fr_H21 = fr_H21.response(index_lambda_star,d_FR_H21);
    chp_H21 = chp_H21.response(index_lambda_star,d_CHP_H21,Temp(time));
    wm_H21 = wm_H21.response(index_lambda_star,d_WM_H21);
     
    %House 22%% (bl, chp, fr)
    fr_H22 = fr_H22.response(index_lambda_star,d_FR_H22);
    chp_H22 = chp_H22.response(index_lambda_star,d_CHP_H22,Temp(time));
    
    %House 23%% (bl, hp, fr, wm, pv, ev-charging)
    hp_H23 = hp_H23.response(index_lambda_star,d_HP_H23,Temp(time));
    fr_H23 = fr_H23.response(index_lambda_star,d_FR_H23);
    wm_H23 = wm_H23.response(index_lambda_star,d_WM_H23);
    ev_H23 = ev_H23.response(index_lambda_star,d_EV_H23,time);
    
    %House 24%% (bl, hp, fr, wm, pv, battery, ev-charging)
    hp_H24 = hp_H24.response(index_lambda_star,d_HP_H24,Temp(time));
    fr_H24 = fr_H24.response(index_lambda_star,d_FR_H24);
    wm_H24 = wm_H24.response(index_lambda_star,d_WM_H24);
    bat_H24 = bat_H24.response(index_lambda_star,d_BAT_H24);
    ev_H24 = ev_H24.response(index_lambda_star,d_EV_H24,time);
     
     
   % Log the value of the lambda_star
   
    list_lambda(time,1) = lambda_star;

   

end


%% *Plot the Equilibrium Price after simulation*

fig3=figure(3);
subplot(2,1,1)
plot(1:96,list_lambda(:,1),'-r','MarkerIndices',1:4:length(list_lambda),'LineWidth',1.5);
hold on
scatter(1:96,list_lambda(:,1),12,'b','filled','c')
axis([0 96 0 1.1])

values_xtick={'00:00','01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00'...
    ,'10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00'...
    ,'22:00','23:00'};
xticks(1:4:96);
xticklabels(values_xtick);
xtickangle(90)
xlabel('Time of Day')
ylabel('Equilibrium Price (p.u.)')

title('Per Unit Equilibrium Prices for Whole Day')

on_peak_price = 0.134;  % [$/kWh]
mid_peak_price = 0.094; % [$/kWh]
off_peak_price = 0.065; % [$/kWh]

market_price = [];

for i=1:length(list_lambda)
    if(list_lambda(i)>0.7)
        market_price(i) = on_peak_price;
    elseif(list_lambda(i)<= 0.7 && list_lambda(i)>=0.3)
        market_price(i) = mid_peak_price;
    else
        market_price(i) = off_peak_price;
    end
end
subplot(2,1,2)
plot(1:96,market_price,'-r','MarkerIndices',1:4:length(market_price),'LineWidth',1.5);
hold on
scatter(1:96,market_price,12,'b','filled','c')
axis([0 96 0 0.15])

values_xtick={'00:00','01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00'...
    ,'10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00'...
    ,'22:00','23:00'};
xticks(1:4:96);
xticklabels(values_xtick);
xtickangle(90)
xlabel('Time of Day')
ylabel('Equilibrium Price ($)')
grid
title('Market Equilibrium Prices for Whole Day')
movegui(fig3,'south')

%% Base Price Calculation
fig4=figure(4);
 %%%%%%%%%%%%%%%% P U Total Price %%%%%%%%%%%%%%%%%%
syms x
%Average_lambda=mean(list_lambda);
time_dur=15/60;
TotalPrice_15_mins=(((x.*list_lambda).*time_dur).*AllHouseDemands)/1000;
TotalPricePerDay=sum(TotalPrice_15_mins);

subplot(2,1,1) 
PerUnit_total=subs(TotalPricePerDay,x,1);
stem(1:24,PerUnit_total,'b','LineWidth',1.5)
xticks([1:1:24])
xlabel('House Number')
ylabel('Price (p.u.)')
title('Total Price for a Day in P.U.')

 %%%%%%%%%%%%%%%% Market Total Price %%%%%%%%%%%%%%%%%%
subplot(2,1,2)

Average_lambda_dol=mean(market_price');
time_dur=15/60;
TotalPrice_15_mins_dol=(((x.*market_price').*time_dur).*AllHouseDemands)/1000;
TotalPricePerDay_dol=sum(TotalPrice_15_mins_dol);
Market_total=subs(TotalPricePerDay_dol,x,1);
stem(1:24,Market_total,'r','LineWidth',1.5)
xticks([1:1:24])
xlabel('House Number')
ylabel('Price ($)')
title('Total Price for a Day in ($)')
movegui(fig4,'north')
%% Plotting Base Loads
% close all
% figure(5)
% for k=1:6
%     if k==1
%         subplot(3,2,1)
%         for i =1:4
%             plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H1','H2','H3','H4')
%     end
%     if k==2
%         subplot(3,2,3)
%         for i =5:8
%             plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H5','H6','H7','H8')
%     end
%     if k==3
%         subplot(3,2,5)
%         for i =9:12
%             plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H9','H10','H11','H12')
%     end
%     if k==4
%         subplot(3,2,2)
%         for i =13:16
%             plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H13','H14','H15','H16')
%     end
%     if k==5
%         subplot(3,2,4)
%         for i =17:20
%             plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H17','H18','H19','H20')
%     end
%     if k==6
%         subplot(3,2,6)
%         for i =21:24
%         plot(1:96, All_Base_loads(i,:));hold on
%         end
%         values_xtick={'00:00','03:00','06:00','09:00'...
%                 ,'12:00','15:00','18:00','21:00'...
%            ,'23:00'};
%         xticks(linspace(1,96,9));
%         xticklabels(values_xtick);
%         xtickangle(90)
%         xlabel('Time of Day')
%         ylabel('Base Load (kW)')
%         grid
%         legend('H21','H22','H23','H24')
%    end
% end
% 
% sgtitle('Variability of Base Loads for all the Houses')
% 
% 
% 



