function d = bidcurve(bl, id, time)
%BIDCURVE Summary of this function goes here
%   Detailed explanation goes here

d = ones(size(id))*bl.load(time); % Flat bidcurve, consume anyway
end