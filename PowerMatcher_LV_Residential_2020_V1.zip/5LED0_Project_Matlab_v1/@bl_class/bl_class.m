classdef bl_class
    %BL_CLASS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        load
    end
    
    methods
        function bl = bl_class(load)
            bl.load = load;
        end
    end
    
end

