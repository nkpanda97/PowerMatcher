stairs(id,[d_BL(:) d_PV(:) d_HP(:) d_FR(:) d_CHP(:) d_WM(:)],'LineWidth',1);
hold on
stairs(id,agg_bid,'LineWidth',2,'Color','k');
plot(id(ind_lambda_star),agg_bid(ind_lambda_star),'r*','MarkerSize',10);
hold off
hleg = legend('Base load','PV generation','Heat pump','Freezer','CHP','Washing machine', 'Aggregated bid','\lambda *');
hleg.NumColumns = 2;
hleg.EdgeColor = 'None';
hleg.Color = 'None';
grid ON;
ax = gca;
% ax.GridColor = [0 .5 .5];
ax.GridLineStyle = ':';
ax.GridAlpha = 0.5;
ax.Layer = 'top';




hour = fix(time/4);
minute = (time/4 - hour)*60;
title_name = strcat('Bidcurves - Window @ ', num2str(hour),':', num2str(minute));
title(title_name)
xlabel('\lambda','fontsize',13)
ylabel('Power (kW)','fontsize',13)