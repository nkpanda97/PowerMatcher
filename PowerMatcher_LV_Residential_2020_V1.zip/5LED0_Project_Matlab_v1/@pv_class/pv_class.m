classdef pv_class
    %BL_CLASS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Wp = 1590*20;
        
        irrad
    end
    
    methods
        function pv = pv_class(irrad)
            pv.irrad = irrad;
        end
    end
    
end