function d = bidcurve(pv, id, time)
%BIDCURVE Summary of this function goes here
%   Detailed explanation goes here

d = -ones(size(id))*pv.irrad(time)*pv.Wp; % Flat bidcurve, produce anyway
end