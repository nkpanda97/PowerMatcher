function d = bidcurve(bat, id)

d=zeros(1,length(id));

% generate bid curves based on SOC (5 possible curves)
if(bat.SOC_bat >= 40 && bat.SOC_bat < 60)
    for i=1:length(id)
        if(id(i) >= 0 && id(i) < 0.2)
            d(i) = bat.P_max; %charge with full Prated
        elseif(id(i) >= 0.2 && id(i) < 0.4)
            d(i) = -bat.P_max/0.4*id(i) + 3/2*bat.P_max; %charge based on this linear pricedependent equation
        elseif(id(i) >= 0.4 && id(i) < 0.6)
            d(i) = bat.P_max/2; %charge half Prated
        elseif(id(i) >= 0.6 && id(i) < 0.8)
            d(i) = 0; %dont charge/discharge (deadband)
        elseif(id(i) >= 0.8 && id(i) <= 1)
            d(i) = -5*bat.P_max*id(i) + 4*bat.P_max; %discharge based on this linear price dependent equation
        end
    end

elseif(bat.SOC_bat >= 20 && bat.SOC_bat < 40)
    for i=1:length(id)
        if(id(i) >= 0 && id(i) < 0.4)
            d(i) = bat.P_max; %charge with full Prated
        elseif(id(i) >= 0.4 && id(i) < 0.6)
            d(i) = -bat.P_max/0.4*id(i) + 2*bat.P_max; %charge based on this linear price dependent equation
        elseif(id(i) >= 0.6 && id(i) < 0.8)
            d(i) = bat.P_max/2; %charge half Prated
        elseif(id(i) >= 0.8 && id(i) <= 1)
            d(i) = 0; %dont charge/discharge (deadband)
        end
    end
    
elseif(bat.SOC_bat >= 60 && bat.SOC_bat < 80)
    for i=1:length(id)
        if(id(i) >= 0 && id(i) < 0.2)
            d(i) = -bat.P_max/0.4*id(i) + bat.P_max;  %charge based on this linear price dependent equation
        elseif(id(i) >= 0.2 && id(i) < 0.4)
            d(i) = bat.P_max/2; %charge with half Prate
        elseif(id(i) >= 0.4 && id(i) < 0.6)
            d(i) = 0; %dont charge/discharge (deadband)
        elseif(id(i) >= 0.6 && id(i) <= 1)
            d(i) = -bat.P_max/0.4*id(i) + 1.5*bat.P_max; %discharge based on this linear price dependent equation
        end
    end
    
elseif(bat.SOC_bat >= 0 && bat.SOC_bat < 20) %SOC 20%-
    for i=1:length(id)
        d(i) = bat.P_max; %charge with full rated power for any price
    end
    
elseif(bat.SOC_bat >= 80) %SOC 80%+
    for i=1:length(id)
        if(id(i) >= 0.2)
            d(i) = -bat.P_max/0.8*id(i) + bat.P_max/4; %discharge based on price
        else
            d(i) = 0; %not willing to discharge if price too low
        end
    end
end
    
        