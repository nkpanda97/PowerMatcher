function bat = response(bat, lamda, d)

    P_bat = d(lamda);

    if(P_bat==0)
        dSOC = bat.SOC_idl;       % No power to charge/discharge battery -> no SOC change
    else
        dSOC = (P_bat*0.25)/bat.E_bat*100; % There is power to charge/discharge battery -> SOC change, every 0.25 hour timestep
    end

    bat.SOC_bat = bat.SOC_bat + dSOC;

end