classdef bat_class
    %BATT_CLASS Battery (storage) class
    %Can act as demand (charging) and supply (discharge)
    %Battery is directly connected to the grid when charging and discharging, not to utilities
    %not for instance charging from pv or discharging to heatpump

    properties
        P_max = 5000; % Maximum battery charge/discharge rate [W]
        E_bat = 13500; % Battery capacity [Wh]
        %Price_low = 0.6; % Price below which the battery will charge
        %Price_high = 0.7; % Price above which the battery will discharge
        SOC_min = 0;
        SOC_max = 100;
        SOC_idl = -0.01; % loss of SOC when idle
        SOC_bat  % Battery state-of-charge
    end
    
    methods
        function bat = bat_class(SOC_bat)
            bat.SOC_bat = SOC_bat;
        end
    end
    
end

