function d = bidcurve(chp, id)

%% prepare values
L=(chp.T_CHP-chp.Tmin)/(chp.Tmax-chp.Tmin);         %calculate buffer level (0-1) []
chp.c1=chp.c1*length(id);            %translate price to index
chp.c2=chp.c2*length(id);            %translate price to index
d=zeros(1,length(id));       %create an empty vector, such that simulink knows a vector is expected. d represents bid curve
heaterstate=zeros(1,length(id));  %create an empty vector, such that simulink knows a vector is expected. Vector resembles whether or not the heater would turn on for the received price

%% create bid curve

for i=1:length(id)
    if(L<chp.L_le)                  %'must run' situation, both heater and CHP on.
        d(i)=chp.Pnomel;
        heaterstate(i)=1;
    elseif(L<=chp.L_l)              %heat demand can be met either by heater or CHP.
        if(i<=chp.c1)               %for low prices, less costs by running heater, not interesting to run CHP
            d(i)=0;
            heaterstate(i)=1;
        else                    %more profitable to run CHP and not run heater
            d(i)=chp.Pnomel;
            heaterstate(i)=0;
        end
    elseif(L<=chp.L_h)              %no direct heat demand. High level of freedom to run CHp
        L_=(L-chp.L_l)/(chp.L_h-chp.L_l);
        c_=chp.c1+(chp.c2-chp.c1)*L_;       %caculate boundary for which chp may run or not
        if(i<=c_)               
            d(i)=0;
            heaterstate(i)=0;
        else
            d(i)=chp.Pnomel;
            heaterstate(i)=0;
        end
    elseif(L<=1)                %no heat demand
        if(i<=chp.c2)               %not profitable to turn on chp and dump heat
            d(i)=0;
            heaterstate(i)=0;
        else                    %profitable enough to produce electricity and dump heat
            d(i)=chp.Pnomel;
            heaterstate(i)=0;
        end
    else                        %buffer maximum, not able to run CHP or run heater
        d(i)=0;
        heaterstate(i)=0;
    end
end

end