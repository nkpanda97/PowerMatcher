classdef chp_class
    %CHP_CLASS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Tmin = 20; %Tmin is minimum temperature for a house, T should stay above this. [deg. C]
        Tmax = 21; %Tmax is maximum temperature for a house, T should stay below this  [deg. C]
        L_le = 0.2; %L_le is the lowest level a buffer may become                       []
        L_l = 0.4; %L_l is the level at which a heater turns off, and only a CHP runs  []
        L_h = 0.8; %L_h is the level at which heat energy is dumped outside, buffer is not filled []
        c1 = 0.3; %c1 is the price at which it becomes profitable for a CHP to run, corresponds to L_l. Is a fraction of the total price  []
        c2 = 0.9; %c2 is the price at which the buffer level is no longer filled, corresponds to L_h. Is a fraction of the total price    []
        Pnomel = -1e3; %Pnom is the nominal electrical power the CHP can deliver           [W]
        
        heaterstate = 0;
        heat_dump = 0;
        Qnomchp = 6e3;
        Qnomheater = 6e3;
        
        Qsupply = 0;                    % Heat supplied by heating device [W]
        Cbuilding = 65.5e6;             % Thermal capacity of building [J/K]
        UA = 214;                       % Thermal loss due to transmission and ventilation, per degree of temperature difference [W/K]
        Qint = 300;                     % Internal generated heat, by people and device [W]
        
        T_CHP
    end
    
    methods
        function chp = chp_class(T_CHP)
            chp.T_CHP = T_CHP;
        end
    end
    
end

