function chp = response(chp, lamda, d, Te)

if(d(lamda)~=0 && chp.heat_dump==0) %Check if CHP is producing heat and heat is not dumped outside (at heat buffer levels higher than L_h
    Qchp=chp.Qnomchp;
else
    Qchp=0;
end

if(chp.heaterstate==1)          %Check if heater is on and produces heat
    Qheater=chp.Qnomheater;
else
    Qheater=0;
end

chp.Qsupply=Qchp+Qheater;


deltaT=Te-chp.T_CHP;         %temperature difference between inside and outside
Qout=chp.UA*deltaT;             %Heat loss due to transmission and ventilation
Qin=chp.Qsupply+chp.Qint;          %Heat supply and internal energy supply
chp.T_CHP=chp.T_CHP+(Qin+Qout)*15*60/chp.Cbuilding;     %temperature change

end