function Aggregate_BidCurve_Feeder(id,Feeder_Demand,Feeder_number,time,index_lambda_star)
%This function shall plot the aggregate demand in staircase graph
%Inputs:
%      id----> The division of per unit price
%      aggregate_Demand---->The aggregate power variable (in id x n vector)
%      where n is the number of houses
%      house_number -------> The house number for which you are plotting (as '1')
%      Feeder Number----> Input the Feeder Number
%      index_lamda_star----> enetr the index of the eqlibrium price
n=size(Feeder_Demand,1); %Number of houses
for i=1:n-1
stairs(id,Feeder_Demand(i,:),'LineWidth',1);hold on
end
hold on;
aggregate_feederDemand=Feeder_Demand(n,:)';
stairs(id,aggregate_feederDemand','LineWidth',2);hold on;
plot(id(index_lambda_star),aggregate_feederDemand(index_lambda_star),'r*','MarkerSize',15);
%plot(id(ind_lambda_star),agg_bid(ind_lambda_star),'r*','MarkerSize',10);
hold off
Text='Distrubutor Number: ';
Text=repmat(Text,n-1,1);
legend_text=[Text, Feeder_number'];
legend_text=[legend_text;'AllDistributor Demand'];

hleg = legend(legend_text);
hleg.NumColumns = 1;
hleg.EdgeColor = 'None';
hleg.Color = 'None';
grid ON;
ax = gca;
ax.GridColor = [0 .5 .5];
ax.GridLineStyle = ':';
ax.GridAlpha = 0.5;
ax.Layer = 'top';
% 
hour = fix(time/4);
    minute = (time/4 - hour)*60;
    title_name = strcat('Bidcurves Window for All Distributors  @ ', num2str(hour),':', num2str(minute));
    title(title_name)

xlabel('\lambda','fontsize',13)
ylabel('Power (kW)','fontsize',13)
end