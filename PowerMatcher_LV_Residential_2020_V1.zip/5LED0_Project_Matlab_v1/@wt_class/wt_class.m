classdef wt_class
    %WindTurbine Class
    %Windturbine is directly coupled to the grid, similar to PV
    %Power Output is based on actual windspeed and specifications of the
    %turbine
    
    properties
        cin = 3;      % Cut-in windspeed [m/s]
        cout = 13;    % Cot-out windspeed [m/s]
        cnom = 11;    % Windspeed @nominal Power
       
        P_nom = 8.5;     % Nominal Power [kW]
        p_max = 10;      % Maximal Power [kW]
       
        WindSpeed
    end
    
    methods
        function wt = wt_class(WindSpeed)
            wt.WindSpeed = WindSpeed;
        end
    end    
end