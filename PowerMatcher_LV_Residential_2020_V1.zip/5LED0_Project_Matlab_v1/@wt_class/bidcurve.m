function d = bidcurve(wt, id, time)
 Wind_k=6.386176*10^-3; %Wind Power COnstant
 %No power generation when wind speed <= Cin
if (wt.WindSpeed(time) <= wt.cin)           
    d = -ones(size(id))*0;  
    
 % Lineair Power output between 0 kW @Cin and 8.5 kW @Cnom  
elseif (wt.WindSpeed(time) > wt.cin) && (wt.WindSpeed(time) <= wt.cnom) 
    d = -ones(size(id))*(Wind_k*wt.WindSpeed(time)^3); 
    
  % Lineair Power output between 8.5 kW @Cnom and 10 kW @Cout   
elseif (wt.WindSpeed(time) > wt.cnom) && (wt.WindSpeed(time) <= wt.cout)
    d = -ones(size(id)).*(8.5);
    
  %No power generation when wind speed > Cout
else 
    d = -ones(size(id))*0;
end
end