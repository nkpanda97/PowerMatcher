function d = bidcurve(wm, id, lambda)

d=zeros(1,length(id));

L = (lambda/10 - wm.Lmin) / (wm.Lmax - wm.Lmin); % Predefined threshold price to allow Washing Machine working

for i=1:length(id)          %create demand bid curve
    if wm.status_WM == 0     % washing machine is off
        if ((id(i)<=L) && (L <1))
                d(i)=wm.Pnom;
            else
                d(i)=0;
        end
    else
        if wm.status_WM == 1 % washing machine is working
            d(i)= wm.Pnom;
        else % whashing machine is finished
            d(i) = 0;
        end
    end    
end
end