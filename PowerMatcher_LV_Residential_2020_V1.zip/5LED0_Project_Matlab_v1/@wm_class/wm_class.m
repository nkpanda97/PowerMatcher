classdef wm_class
    %WM_CLASS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Lmin = 0; % minimum price for washing machine working
        Lmax = 0.8; % maximum price for washing machine working
        Emax = 1000;
        Pnom = 1e3;
        
        status_WM
        E_WM
    end
    
    methods
        function wm = wm_class(status_WM, E_WM)
            wm.status_WM = status_WM;
            wm.E_WM = E_WM;
        end
    end
    
end