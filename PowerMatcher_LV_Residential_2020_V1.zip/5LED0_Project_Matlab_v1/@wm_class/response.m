function wm = response(wm, lamda, d)

P_WM = d(lamda); 

if P_WM > 0
    wm.E_WM = wm.E_WM + P_WM*0.25; % accumulated energy consumption from whashing machine 

    if (wm.status_WM == 0)  % washing machine starts working
        wm.status_WM = 1;    
    else 
        if (wm.status_WM == 1)
            if wm.E_WM >= wm.Emax % washing machine has finished the working load (complete energy max (requested)
                wm.status_WM = 2; 
            end    
        else % washing machine finished - wait for next working day
           
        end    
    end
end
end