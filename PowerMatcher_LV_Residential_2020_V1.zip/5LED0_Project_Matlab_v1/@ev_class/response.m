function ev = response(ev, lamda, d, time)


    P_ev = d(lamda);

    if(time == ev.time_return*4)
     ev.SOC_ev = 20;
     %text = 'Car is back home, reset to 20%'
    else
        
        if(P_ev==0)
        %dSOC = bat.SOC_idl;       % No power to charge/discharge battery
        %-> idle discharge
        dSOC = 0;   % here no charge no discharge we remain at constant SOC
        else
        dSOC = (P_ev*0.25)/ev.E_bat*100; % There is power to charge/discharge battery -> SOC change, every 0.25 hour timestep
        end

        ev.SOC_ev = ev.SOC_ev + dSOC;
    end
end