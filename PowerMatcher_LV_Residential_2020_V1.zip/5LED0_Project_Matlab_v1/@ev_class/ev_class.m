classdef ev_class
  
    properties
        P_max = 11500; % Maximum ev charger charge/discharge rate [W]
        E_bat = 50000; % Battery capacity [Wh] -> Tesla model 3sr
        SOC_min = 0;
        SOC_max = 100;
        %SOC_idl = -0.01; % loss of SOC when idle 
        SOC_ev  % Battery state-of-charge
        time_leave % initialize time when car leaves house (morning) [24 h]
        time_return % when car is plugged in (evening) [24h format]
    end
    
    methods
        function ev = ev_class(SOC_ev, time_leave, time_return)
            ev.SOC_ev = SOC_ev;
            ev.time_leave = time_leave;
            ev.time_return = time_return;
        end
    end
    
end

