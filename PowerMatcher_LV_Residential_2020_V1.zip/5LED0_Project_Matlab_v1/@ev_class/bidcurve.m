function d = bidcurve(ev, id, time)
time_min = (0.8*ev.E_bat)/ev.P_max; %min charging time [h] to charge battery from 20 to 100 SOC
time_Pmax = ev.time_leave - time_min;    % time you must start chargin to have full SOC [h] at time_leave
time_Pmax_int = floor(time_Pmax*4);         % conver time to integer (4 because hour has 4*15 min intervals)

d=zeros(1,length(id));
    
% if(time == ev.time_return*4)
%     ev.SOC_ev = 20;
%     text = 'Car is back home, reset to 20%'
%     
% else
if(floor(ev.time_leave*4) < time && time < ceil(ev.time_return*4)) %if time is after leave AND before return = car is not at home.
    for i=1:length(id)
        d(i) = 0;   
    end
    
elseif(floor(ev.time_leave*4) >= time || time >= ceil(ev.time_return*4)) %if time is before leave OR time is after return = car is at home.
    if(time >= time_Pmax_int && floor(ev.time_leave*4) >= time) %if you must start charging to finish before leaving, but not after returning
        for i=1:length(id)
            if ev.SOC_ev < 95  % check if SOC is below 95
                d(i) = ev.P_max;% charge with max power
            else
                d(i) = 0;       % SOC is 95 and we dont charge (reason for 95: save battery and allow regen braking :) )
            end
        end
    else
        if(ev.SOC_ev >= 40 && ev.SOC_ev < 60)
            for i=1:length(id)
                if(id(i) >= 0 && id(i) < 0.2)
                    d(i) = ev.P_max; %charge with full Prated
                elseif(id(i) >= 0.2 && id(i) < 0.4)
                    d(i) = -ev.P_max/0.4*id(i) + 3/2*ev.P_max; %charge based on this linear pricedependent equation
                elseif(id(i) >= 0.4 && id(i) < 0.6)
                    d(i) = ev.P_max/2; %charge half Prated
                elseif(id(i) >= 0.6 && id(i) < 0.8)
                    d(i) = 0; %dont charge/discharge (deadband)
                elseif(id(i) >= 0.8 && id(i) <= 1)
                    d(i) = -5*ev.P_max*id(i) + 4*ev.P_max; %discharge based on this linear price dependent equation
                end
            end

        elseif(ev.SOC_ev >= 20 && ev.SOC_ev < 40)
            for i=1:length(id)
                if(id(i) >= 0 && id(i) < 0.4)
                    d(i) = ev.P_max; %charge with full Prated
                elseif(id(i) >= 0.4 && id(i) < 0.6)
                    d(i) = -ev.P_max/0.4*id(i) + 2*ev.P_max; %charge based on this linear price dependent equation
                elseif(id(i) >= 0.6 && id(i) < 0.8)
                    d(i) = ev.P_max/2; %charge half Prated
                elseif(id(i) >= 0.8 && id(i) <= 1)
                    d(i) = ev.P_max/8; %charge with very low power 1/8 of max charging power
                end
            end

        elseif(ev.SOC_ev >= 60 && ev.SOC_ev < 80)
            for i=1:length(id)
                if(id(i) >= 0 && id(i) < 0.2)
                    d(i) = -ev.P_max/0.4*id(i) + ev.P_max;  %charge based on this linear price dependent equation
                elseif(id(i) >= 0.2 && id(i) < 0.4)
                    d(i) = ev.P_max/2; %charge with half Prate
                elseif(id(i) >= 0.4 && id(i) < 0.6)
                    d(i) = 0; %dont charge/discharge (deadband)
                elseif(id(i) >= 0.6 && id(i) <= 1)
                    d(i) = -ev.P_max/0.4*id(i) + 1.5*ev.P_max; %discharge based on this linear price dependent equation
                end
            end

        elseif(ev.SOC_ev >= 0 && ev.SOC_ev < 20) %SOC 20%-
            for i=1:length(id)
                d(i) = ev.P_max; %charge with full rated power for any price
            end

        elseif(ev.SOC_ev >= 80) %SOC 80%+
            for i=1:length(id)
                if(id(i) >= 0.2)
                    d(i) = -ev.P_max/0.8*id(i) + ev.P_max/4; %discharge based on price
                else
                    d(i) = 0; %not willing to discharge if price too low
                end
            end
        end

    
    
end    
end  
end

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
% if(time >= time_Pmax_int && time < floor(ev.time_leave*4))   % must start charging to ensure full battery
%     for i=1:length(id)
%         if ev.SOC_ev < 100  % check if SOC is below 100 
%             d(i) = ev.P_max;% charge with max power
%         else
%             d(i) = 0;       % SOC is 100 and we dont charge
%         end
%     end
% 
%     
%     
%     
% elseif(time > floor(ev.time_leave*4) && time < ceil(ev.time_return*4)) % not home
%     for i=1:length(id)
%         d(i) = 0;   
%     end
%     
% elseif(time == ev.time_return*4) % reset SOC to 20 % between plugging in and must charge
%         ev.SOC_ev = 20;
%         text = 'grizoirresetiki20'
%     
% else
%         % generate bid curves based on SOC (5 possible curves)
% if(ev.SOC_ev >= 40 && ev.SOC_ev < 60)
%     for i=1:length(id)
%         if(id(i) >= 0 && id(i) < 0.2)
%             d(i) = ev.P_max; %charge with full Prated
%         elseif(id(i) >= 0.2 && id(i) < 0.4)
%             d(i) = -ev.P_max/0.4*id(i) + 3/2*ev.P_max; %charge based on this linear pricedependent equation
%         elseif(id(i) >= 0.4 && id(i) < 0.6)
%             d(i) = ev.P_max/2; %charge half Prated
%         elseif(id(i) >= 0.6 && id(i) < 0.8)
%             d(i) = 0; %dont charge/discharge (deadband)
%         elseif(id(i) >= 0.8 && id(i) <= 1)
%             d(i) = -5*ev.P_max*id(i) + 4*ev.P_max; %discharge based on this linear price dependent equation
%         end
%     end
% 
% elseif(ev.SOC_ev >= 20 && ev.SOC_ev < 40)
%     for i=1:length(id)
%         if(id(i) >= 0 && id(i) < 0.4)
%             d(i) = ev.P_max; %charge with full Prated
%         elseif(id(i) >= 0.4 && id(i) < 0.6)
%             d(i) = -ev.P_max/0.4*id(i) + 2*ev.P_max; %charge based on this linear price dependent equation
%         elseif(id(i) >= 0.6 && id(i) < 0.8)
%             d(i) = ev.P_max/2; %charge half Prated
%         elseif(id(i) >= 0.8 && id(i) <= 1)
%             d(i) = 0; %dont charge/discharge (deadband)
%         end
%     end
%     
% elseif(ev.SOC_ev >= 60 && ev.SOC_ev < 80)
%     for i=1:length(id)
%         if(id(i) >= 0 && id(i) < 0.2)
%             d(i) = -ev.P_max/0.4*id(i) + ev.P_max;  %charge based on this linear price dependent equation
%         elseif(id(i) >= 0.2 && id(i) < 0.4)
%             d(i) = ev.P_max/2; %charge with half Prate
%         elseif(id(i) >= 0.4 && id(i) < 0.6)
%             d(i) = 0; %dont charge/discharge (deadband)
%         elseif(id(i) >= 0.6 && id(i) <= 1)
%             d(i) = -ev.P_max/0.4*id(i) + 1.5*ev.P_max; %discharge based on this linear price dependent equation
%         end
%     end
%     
% elseif(ev.SOC_ev >= 0 && ev.SOC_ev < 20) %SOC 20%-
%     for i=1:length(id)
%         d(i) = ev.P_max; %charge with full rated power for any price
%     end
%     
% elseif(ev.SOC_ev >= 80) %SOC 80%+
%     for i=1:length(id)
%         if(id(i) >= 0.2)
%             d(i) = -ev.P_max/0.8*id(i) + ev.P_max/4; %discharge based on price
%         else
%             d(i) = 0; %not willing to discharge if price too low
%         end
%     end
% end
% 
% 
% end
